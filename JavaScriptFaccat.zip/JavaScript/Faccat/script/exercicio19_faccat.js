let valor1 = parseInt(prompt("Digite o primeiro valor:"));
let valor2 = parseInt(prompt("Digite o segundo valor:"));

if (valor1 > valor2) {
    alert("O maior valor é: " + valor1);
} else {
    alert("O maior valor é: " + valor2);
}
