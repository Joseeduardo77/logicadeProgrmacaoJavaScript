let fahrenheit = parseFloat(prompt("Digite a temperatura em Fahrenheit: "))

let celsius = (5 / 9) * (fahrenheit - 32)

alert("A temperatura correspondente em Celsius é: " + celsius)
