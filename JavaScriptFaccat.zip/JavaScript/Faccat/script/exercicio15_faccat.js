let valor = parseFloat(prompt("Digite um valor:"));

if (valor >= 0) {
    alert("O valor é POSITIVO!");
} else {
    alert("O valor é NEGATIVO!");
}
