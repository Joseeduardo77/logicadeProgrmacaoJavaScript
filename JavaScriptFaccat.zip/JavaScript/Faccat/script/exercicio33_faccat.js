let numero1 = parseInt(prompt("Digite o primeiro número:"));
let numero2 = parseInt(prompt("Digite o segundo número:"));

if (numero1 === numero2) {
    alert("Números iguais");
} else if (numero1 > numero2) {
    alert("Primeiro é maior");
} else {
    alert("Segundo maior");
}
