let valor = parseFloat(prompt("Digite um valor:"));

if (valor > 10) {
    alert("O valor é maior que 10!");
} else {
    alert("O valor é menor que 10!");
}
