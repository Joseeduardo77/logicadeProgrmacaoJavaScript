alert("Exercício (c): Soma dos números de 1 a 100");
let soma100 = 0;
let k = 1;
do {
  soma100 += k;
  k++;
} while (k <= 100);
alert("A soma dos números de 1 a 100 é: " + soma100);