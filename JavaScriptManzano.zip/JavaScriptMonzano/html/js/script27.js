let numero = parseInt(prompt("Digite um número:"));
let modulo = Math.abs(numero);

alert(`O módulo do número é: ${modulo}`);