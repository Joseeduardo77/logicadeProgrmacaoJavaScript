let celsius = parseFloat(prompt("Digite a temperatura em graus Celsius:"));
let fahrenheit = (celsius * 9 / 5) + 32;
alert(`Temperatura em Fahrenheit: ${fahrenheit.toFixed(2)} °F`);