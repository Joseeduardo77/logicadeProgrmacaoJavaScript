let numA = parseFloat(prompt("Digite o valor de A:"));
let numB = parseFloat(prompt("Digite o valor de B:"));
let numC = parseFloat(prompt("Digite o valor de C:"));
let numD = parseFloat(prompt("Digite o valor de D:"));
let resultado = (numA * numC) + (numB * numD);
alert(`Resultado da operação (A*C + B*D): ${resultado}`);