let A = parseInt(prompt("Digite o valor de A:"));
let B = parseInt(prompt("Digite o valor de B:"));
let C = parseInt(prompt("Digite o valor de C:"));
let D = parseInt(prompt("Digite o valor de D:"));

let P = A * C;
let S = B + D;

alert(`Produto do primeiro com o terceiro valor (A * C): ${P}`);
alert(`Soma do segundo com o quarto valor (B + D): ${S}`);