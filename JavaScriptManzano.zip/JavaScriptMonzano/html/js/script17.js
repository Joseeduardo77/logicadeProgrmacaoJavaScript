let comprimento = parseFloat(prompt("Digite o comprimento da caixa:"));
let largura = parseFloat(prompt("Digite a largura da caixa:"));
altura = parseFloat(prompt("Digite a altura da caixa:"));
let volumeCaixa = comprimento * largura * altura;
alert(`Volume da caixa retangular: ${volumeCaixa} unidades cúbicas`);