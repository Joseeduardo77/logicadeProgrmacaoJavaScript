alert("Exercício (a) - Quadrados dos números de 15 a 200");

let i = 15;
do {
  alert("O quadrado de " + i + " é " + (i * i));
  i++;
} while (i <= 200);
