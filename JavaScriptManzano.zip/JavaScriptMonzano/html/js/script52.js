alert("Exercício (e): Soma dos números de 1 a 500");
let soma500 = 0;
let m = 1;
do {
  soma500 += m;
  m++;
} while (m <= 500);
alert("A soma dos números de 1 a 500 é: " + soma500);