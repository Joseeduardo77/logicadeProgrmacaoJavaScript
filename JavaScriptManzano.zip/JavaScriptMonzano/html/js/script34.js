let numeroParImpar = parseInt(prompt("Digite um número:"));

if (numeroParImpar % 2 === 0) {
    alert(`O número ${numeroParImpar} é par.`);
} else {
    alert(`O número ${numeroParImpar} é ímpar.`);
}
