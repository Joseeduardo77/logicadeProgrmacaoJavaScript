let num1 = parseFloat(prompt("Digite o primeiro número:"));
let num2 = parseFloat(prompt("Digite o segundo número:"));
let quadradoDiferenca = Math.pow(num1 - num2, 2);
alert(`Quadrado da diferença: ${quadradoDiferenca}`);
