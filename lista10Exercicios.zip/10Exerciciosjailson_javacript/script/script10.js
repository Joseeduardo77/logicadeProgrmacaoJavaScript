let senha;

do {
    senha = prompt("Digite a senha:");
} while (senha !== "1234");

alert("Senha correta! Acesso liberado.");
