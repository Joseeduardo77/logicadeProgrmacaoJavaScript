let contador = 1;

do {
    alert(contador);
    contador = contador + 1;
} while (contador <= 10);
