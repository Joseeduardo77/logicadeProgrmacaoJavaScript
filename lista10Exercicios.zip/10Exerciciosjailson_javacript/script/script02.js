let numero = parseInt(prompt("Digite um número:"));

do {
    alert(numero);
    numero = numero - 1;
} while (numero >= 0);
