let num1 = parseFloat(prompt("Digite o primeiro número:"));
let num2 = parseFloat(prompt("Digite o segundo número:"));

let multiplicacao = num1 * num2;
alert("A multiplicação dos números é: " + multiplicacao);